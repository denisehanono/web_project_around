Around the U.S

Jacques Cousteau es un explorador que vive en EE.UU. y explora los mejores paisajes de EE.UU.
En ésta página, puedes ver las imágenes que tiene Jacques Cousteau, y también puedes crear tus propias imágenes.

Para crear tu propia imagen, debes ir a la sección "New Place" y rellenar los campos de título y url.
Puedes editar tu perfil, y también borrar imágenes. 

Sitio Web:  https://denisehanono.github.io/web_project_around/ 
_____________

Sprint 9 - Web Project Around
Denise Hanono. 2024